package com.example

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * مستودع بيانات الطابور (Repository) باستخدام Firebase Realtime Database
 * يعتمد على إعدادات [Tabor] لإنجاز العمليات لحظياً.
 */
class TaborFirebaseRepository {

    /**
     * دالة مساعدة لتحويل Task من Google GMS إلى دالة معلقة (Coroutine Suspending Function)
     * بدون الحاجة لاستيراد مكتبات خارجية معقدة.
     */
    private suspend fun <T> com.google.android.gms.tasks.Task<T>.awaitTask(): T =
        suspendCancellableCoroutine { continuation ->
            addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    continuation.resume(task.result)
                } else {
                    continuation.resumeWithException(task.exception ?: RuntimeException("Firebase operation failed"))
                }
            }
        }

    /**
     * الاستماع للحالة اللحظية للعيادة عبر callbackFlow.
     * يستمع للتغييرات في العقدة المحددة بملف Tabor ويرسل التحديثات تلقائياً.
     */
    fun observeQueueData(): Flow<QueueData> = callbackFlow {
        val ref = Tabor.getClinicReference()
        
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val currentPatient = snapshot.child("currentPatient").getValue(Patient::class.java)
                val lastCalledAt = snapshot.child("lastCalledAt").getValue(Long::class.java) ?: 0L
                
                val waitingPatients = mutableMapOf<String, Patient>()
                snapshot.child("waitingPatients").children.forEach { child ->
                    child.getValue(Patient::class.java)?.let { patient ->
                        waitingPatients[child.key ?: ""] = patient
                    }
                }

                val skippedPatients = mutableMapOf<String, Patient>()
                snapshot.child("skippedPatients").children.forEach { child ->
                    child.getValue(Patient::class.java)?.let { patient ->
                        skippedPatients[child.key ?: ""] = patient
                    }
                }
                
                // إرسال البيانات المحدثة للمستمعين
                trySend(QueueData(currentPatient, waitingPatients, skippedPatients, lastCalledAt))
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        ref.addValueEventListener(listener)

        // إزالة المستمع عند إلغاء الـ Flow (الـ Coroutine Scope) لمنع تسرب الذاكرة
        awaitClose {
            ref.removeEventListener(listener)
        }
    }

    /**
     * إضافة مراجع جديد إلى قائمة الانتظار.
     * تقوم بإدراج المراجع مباشرة في العقدة باستخدام الرقم التسلسلي المحدد مسبقاً.
     */
    suspend fun addPatientToQueue(name: String, nextNumber: Int) {
        val ref = Tabor.getClinicReference()

        // توليد مفتاح فريد جديد للمراجع
        val newKey = ref.child("waitingPatients").push().key ?: System.currentTimeMillis().toString()
        
        val sdf = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.ENGLISH)
        val regTime = sdf.format(java.util.Date()).uppercase()

        val newPatient = Patient(
            id = newKey,
            name = name.trim(),
            number = nextNumber,
            addedAt = System.currentTimeMillis(),
            registrationTime = regTime
        )

        ref.child("waitingPatients").child(newKey).setValue(newPatient)
    }

    /**
     * استدعاء مريض معين في الطابور ونقله كـ مريض حالي.
     * تتم هذه العملية لحظياً وبشكل متوافق بالكامل مع العمل بدون إنترنت (Offline-first).
     */
    suspend fun callPatient(patient: Patient) {
        val ref = Tabor.getClinicReference()
        val updates = hashMapOf<String, Any?>(
            "currentPatient" to patient,
            "waitingPatients/${patient.id}" to null,
            "lastCalledAt" to System.currentTimeMillis()
        )
        ref.updateChildren(updates)
    }

    /**
     * إعادة استدعاء المريض الحالي.
     * تقوم فقط بتحديث الطابع الزمني `lastCalledAt` لإعادة تشغيل التنبيه الصوتي على التلفزيون.
     */
    suspend fun recallCurrentPatient() {
        val ref = Tabor.getClinicReference()
        ref.child("lastCalledAt").setValue(System.currentTimeMillis())
    }

    /**
     * إزالة مريض معين يدوياً من قائمة الانتظار (في حال مغادرته أو إلغاء الموعد).
     */
    suspend fun removePatientFromQueue(patientId: String) {
        val ref = Tabor.getClinicReference()
        ref.child("waitingPatients").child(patientId).setValue(null)
    }

    /**
     * تأجيل المراجع الحالي ونقله لنهاية طابور الانتظار
     */
    suspend fun postponeCurrentPatient(currentPatient: Patient, nextPatient: Patient?) {
        val ref = Tabor.getClinicReference()
        val updates = hashMapOf<String, Any?>()
        
        // وضع المراجع الحالي في نهاية قائمة الانتظار بطابع زمني جديد
        val postponedPatient = currentPatient.copy(addedAt = System.currentTimeMillis())
        updates["waitingPatients/${currentPatient.id}"] = postponedPatient
        
        if (nextPatient != null) {
            updates["currentPatient"] = nextPatient
            updates["waitingPatients/${nextPatient.id}"] = null
            updates["lastCalledAt"] = System.currentTimeMillis()
        } else {
            updates["currentPatient"] = null
        }
        
        ref.updateChildren(updates)
    }

    /**
     * تخطي المراجع الحالي ونقله لقائمة الغائبين/المتخلفين
     */
    suspend fun skipCurrentPatient(currentPatient: Patient) {
        val ref = Tabor.getClinicReference()
        val updates = hashMapOf<String, Any?>(
            "currentPatient" to null,
            "skippedPatients/${currentPatient.id}" to currentPatient,
            "waitingPatients/${currentPatient.id}" to null
        )
        ref.updateChildren(updates)
    }

    /**
     * إعادة استدعاء مراجع غائب وإرجاعه لطابور الانتظار
     */
    suspend fun recallSkippedPatient(patient: Patient) {
        val ref = Tabor.getClinicReference()
        val updatedPatient = patient.copy(addedAt = System.currentTimeMillis())
        val updates = hashMapOf<String, Any?>(
            "skippedPatients/${patient.id}" to null,
            "waitingPatients/${patient.id}" to updatedPatient
        )
        ref.updateChildren(updates)
    }

    /**
     * تصفير الطابور بالكامل (إعادة ضبط لليوم الجديد).
     */
    suspend fun clearQueue() {
        val ref = Tabor.getClinicReference()
        val updates = hashMapOf<String, Any?>(
            "currentPatient" to null,
            "waitingPatients" to null,
            "skippedPatients" to null,
            "lastCalledAt" to 0L
        )
        ref.updateChildren(updates)
    }
}
