package com.example

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

/**
 * حالة واجهة المستخدم الخاصة بالطابور
 */
data class QueueUiState(
    val isLoading: Boolean = true,
    val queueData: QueueData = QueueData(),
    val errorMessage: String? = null,
    val isActionInProgress: Boolean = false,
    val rotationDegree: Float = Tabor.DEFAULT_ROTATION_DEGREE
)

/**
 * ViewModel الخاص بإدارة حالة نظام الطوابير
 * يربط بين طبقة البيانات المتمثلة في [TaborFirebaseRepository] والواجهات الرسومية (التحكم والعرض)
 */
class QueueViewModel : ViewModel() {

    private val repository = TaborFirebaseRepository()

    private val _uiState = MutableStateFlow(QueueUiState())
    val uiState: StateFlow<QueueUiState> = _uiState.asStateFlow()

    init {
        observeQueueData()
    }

    /**
     * الاستماع للتحديثات اللحظية من قاعدة البيانات وتحديث الحالة فوراً
     */
    private fun observeQueueData() {
        viewModelScope.launch {
            repository.observeQueueData()
                .catch { exception ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "فشل في الاتصال بلحظية قاعدة البيانات: ${exception.localizedMessage}"
                    )
                }
                .collect { data ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        queueData = data,
                        errorMessage = null
                    )
                }
        }
    }

    /**
     * إضافة مراجع جديد إلى قائمة الانتظار
     */
    fun addPatient(name: String, onComplete: () -> Unit = {}) {
        if (name.isBlank()) return
        
        // حساب أعلى رقم تسلسلي مسجل حالياً من الحالة المحلية لضمان ترقيم فوري
        val currentData = _uiState.value.queueData
        var maxNumber = 0
        currentData.currentPatient?.let {
            maxNumber = maxOf(maxNumber, it.number)
        }
        currentData.waitingPatients.values.forEach { patient ->
            maxNumber = maxOf(maxNumber, patient.number)
        }
        val nextNumber = maxNumber + 1

        viewModelScope.launch {
            setLoadingAction(true)
            try {
                repository.addPatientToQueue(name, nextNumber)
                onComplete()
            } catch (e: Exception) {
                setError(e.localizedMessage)
            } finally {
                setLoadingAction(false)
            }
        }
    }

    /**
     * استدعاء المراجع التالي في الطابور
     */
    fun callNext() {
        val waitingList = _uiState.value.queueData.waitingPatients.values.toList()
        if (waitingList.isEmpty()) return

        // الحصول على المراجع صاحب أقدم وقت إضافة (المراجع التالي في الدور)
        val nextPatient = waitingList.minByOrNull { it.addedAt } ?: return

        viewModelScope.launch {
            setLoadingAction(true)
            try {
                repository.callPatient(nextPatient)
            } catch (e: Exception) {
                setError(e.localizedMessage)
            } finally {
                setLoadingAction(false)
            }
        }
    }

    /**
     * إعادة استدعاء المراجع الحالي لتنبيهه مجدداً
     */
    fun recallCurrent() {
        viewModelScope.launch {
            setLoadingAction(true)
            try {
                repository.recallCurrentPatient()
            } catch (e: Exception) {
                setError(e.localizedMessage)
            } finally {
                setLoadingAction(false)
            }
        }
    }

    /**
     * تأجيل المراجع الحالي ونقله لنهاية قائمة الانتظار، واستدعاء المراجع التالي إن وجد
     */
    fun postponeCurrentPatient() {
        val currentPatient = _uiState.value.queueData.currentPatient ?: return
        val waitingList = _uiState.value.queueData.waitingPatients.values.toList()
        val nextPatient = waitingList.minByOrNull { it.addedAt }

        viewModelScope.launch {
            setLoadingAction(true)
            try {
                repository.postponeCurrentPatient(currentPatient, nextPatient)
            } catch (e: Exception) {
                setError(e.localizedMessage)
            } finally {
                setLoadingAction(false)
            }
        }
    }

    /**
     * تخطي المراجع الحالي ونقله لقائمة المراجعين الغائبين/المتخلفين
     */
    fun skipCurrentPatient() {
        val currentPatient = _uiState.value.queueData.currentPatient ?: return

        viewModelScope.launch {
            setLoadingAction(true)
            try {
                repository.skipCurrentPatient(currentPatient)
            } catch (e: Exception) {
                setError(e.localizedMessage)
            } finally {
                setLoadingAction(false)
            }
        }
    }

    /**
     * إعادة استدعاء مراجع متخلف/غائب وإرجاعه لطابور الانتظار
     */
    fun recallSkippedPatient(patient: Patient) {
        viewModelScope.launch {
            setLoadingAction(true)
            try {
                repository.recallSkippedPatient(patient)
            } catch (e: Exception) {
                setError(e.localizedMessage)
            } finally {
                setLoadingAction(false)
            }
        }
    }

    /**
     * حذف مراجع من الطابور
     */
    fun removePatient(patientId: String) {
        viewModelScope.launch {
            setLoadingAction(true)
            try {
                repository.removePatientFromQueue(patientId)
            } catch (e: Exception) {
                setError(e.localizedMessage)
            } finally {
                setLoadingAction(false)
            }
        }
    }

    /**
     * تصفير وإعادة تهيئة الطابور بالكامل لليوم الجديد
     */
    fun clearQueue() {
        viewModelScope.launch {
            setLoadingAction(true)
            try {
                repository.clearQueue()
            } catch (e: Exception) {
                setError(e.localizedMessage)
            } finally {
                setLoadingAction(false)
            }
        }
    }

    /**
     * تدوير الشاشة بمقدار 90 درجة تتابعية (0 -> 90 -> 180 -> 270)
     */
    fun rotateScreen() {
        val nextDegree = (_uiState.value.rotationDegree + 90f) % 360f
        _uiState.value = _uiState.value.copy(rotationDegree = nextDegree)
    }

    /**
     * تنظيف رسالة الخطأ بعد عرضها
     */
    fun clearErrorMessage() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    private fun setLoadingAction(inProgress: Boolean) {
        _uiState.value = _uiState.value.copy(isActionInProgress = inProgress)
    }

    private fun setError(msg: String?) {
        _uiState.value = _uiState.value.copy(errorMessage = msg)
    }
}
