package com.example

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

/**
 * ملف الإعدادات المنفصل Tabor
 * يهدف هذا الكائن الأحادي (Singleton) لعزل إعدادات العميل لتسهيل ترخيص وبيع النسخ
 * لمختلف العيادات والمراكز الطبية دون الحاجة لتعديل الكود الأساسي للتطبيق.
 */
object Tabor {
    // 1. بيانات العيادة والترخيص
    const val CLINIC_ID: String = "clinic_smart_demo_01"
    const val CLIENT_NAME: String = "مجمع عيادات الشفاء التخصصي"
    const val DOCTOR_NAME: String = "د. أحمد محمد"
    const val LICENSE_KEY: String = "LIC-XYZ-9988-7766-COM"

    // 2. إعدادات قاعدة بيانات Firebase Realtime Database للعميل
    // تم ربط بيانات Firebase الخاصة بك هنا بشكل منظم وسهل التبديل
    const val API_KEY: String = "AIzaSyDvBKtGNEvxeZrmg72yAPqIJ2OCKu_utl8"
    const val AUTH_DOMAIN: String = "bdns-cb0d6.firebaseapp.com"
    const val DATABASE_URL: String = "https://bdns-cb0d6-default-rtdb.europe-west1.firebasedatabase.app"
    const val PROJECT_ID: String = "bdns-cb0d6"
    const val STORAGE_BUCKET: String = "bdns-cb0d6.firebasestorage.app"
    const val MESSAGING_SENDER_ID: String = "799954839683"
    const val APP_ID: String = "1:799954839683:web:adf11435db2cf8cfcb13b6"
    const val MEASUREMENT_ID: String = "G-M6T1QHCL4W"

    // 3. إعدادات شاشة العرض والصوت
    const val PLAY_SOUND_ON_CALL: Boolean = true
    const val SHOW_UPCOMING_COUNT: Int = 4 // عدد المرضى القادمين المعروضين في شاشة التلفزيون
    const val TICKER_MESSAGE: String = "مرحباً بكم في مجمع عيادات الشفاء. الرجاء الجلوس بانتظام وانتظار نداء السكرتارية. نتمنى لكم وافر الصحة والشفاء العاجل."
    const val DEFAULT_ROTATION_DEGREE: Float = 90f // درجة التدوير التلقائي الافتراضي لشاشة التلفزيون تلقائياً (مثلاً: 90 أو 0 أو 270)

    /**
     * دالة لتهيئة تطبيق Firebase برمجياً بدون الاعتماد على ملف google-services.json
     * هذا يضمن استقرار الكود وحل مشكلة عدم عمل زر تسجيل المريض وأي عمليات قاعدة بيانات أخرى
     */
    fun initializeFirebase(context: Context) {
        try {
            // نقوم بحذف أي تطبيق معرّف مسبقاً لضمان استخدام إعدادات Tabor المخصصة بشكل صحيح تماماً
            val existingApps = FirebaseApp.getApps(context)
            if (existingApps.isNotEmpty()) {
                for (app in existingApps) {
                    if (app.name == FirebaseApp.DEFAULT_APP_NAME) {
                        app.delete()
                    }
                }
            }
        } catch (e: Exception) {
            // تجاهل الاستثناء في حال عدم وجود تطبيق مسبق أو فشل عملية الحذف
        }

        try {
            val options = FirebaseOptions.Builder()
                .setApiKey(API_KEY)
                .setApplicationId(APP_ID)
                .setDatabaseUrl(DATABASE_URL)
                .setProjectId(PROJECT_ID)
                .setStorageBucket(STORAGE_BUCKET)
                .setGcmSenderId(MESSAGING_SENDER_ID)
                .build()
            val app = FirebaseApp.initializeApp(context.applicationContext, options)
        } catch (e: Exception) {
            // تجاهل الاستثناء أو التعامل معه
        }
    }

    /**
     * دالة ترجع المرجع المباشر للعيادة الحالية في قاعدة البيانات
     * المسار المباشر: "clinics/$CLINIC_ID"
     */
    fun getClinicReference(): DatabaseReference {
        val database = if (DATABASE_URL.isNotEmpty()) {
            FirebaseDatabase.getInstance(DATABASE_URL)
        } else {
            FirebaseDatabase.getInstance()
        }
        return database.getReference("clinics/$CLINIC_ID")
    }
}
