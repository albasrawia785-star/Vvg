package com.example

/**
 * هيكل بيانات المريض (Patient Model)
 * يحتوي على المنشئ الافتراضي (Default values) لتسهيل القراءة والكتابة التلقائية في Firebase.
 */
data class Patient(
    val id: String = "",
    val name: String = "",
    val number: Int = 0,
    val addedAt: Long = 0L,
    val registrationTime: String = ""
)

/**
 * نموذج حالة الدور للعيادة (QueueData Model)
 * يمثل الهيكل العام لعقدة العيادة في Firebase Realtime Database.
 */
data class QueueData(
    val currentPatient: Patient? = null,
    val waitingPatients: Map<String, Patient> = emptyMap(),
    val skippedPatients: Map<String, Patient> = emptyMap(),
    val lastCalledAt: Long = 0L // طابع زمني يتم تحديثه عند الاستدعاء لإطلاق صوت التنبيه في الشاشة
)

/*
========================================================================
هيكل الـ JSON المتوقع في قاعدة بيانات Firebase Realtime Database:
========================================================================

{
  "clinics": {
    "clinic_smart_demo_01": {
      "currentPatient": {
        "id": "-O1A2B3C4D5E",
        "name": "محمد أحمد عبدالله",
        "number": 24,
        "addedAt": 1721515800000
      },
      "waitingPatients": {
        "-O1A2B3C4D5E": {
          "id": "-O1A2B3C4D5E",
          "name": "محمد أحمد عبدالله",
          "number": 24,
          "addedAt": 1721515800000
        },
        "-O5F6G7H8I9J": {
          "id": "-O5F6G7H8I9J",
          "name": "زينب علي حسين",
          "number": 25,
          "addedAt": 1721515920000
        },
        "-O9K0L1M2N3O": {
          "id": "-O9K0L1M2N3O",
          "name": "عبدالرحمن سعد جاسم",
          "number": 26,
          "addedAt": 1721516040000
        }
      },
      "lastCalledAt": 1721516100000
    }
  }
}
*/
